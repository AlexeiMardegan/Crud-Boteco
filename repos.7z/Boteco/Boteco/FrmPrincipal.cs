﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Boteco
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult(); // DialogResult é o nome da caixinha, por exemplo quando você vai sair da aplicação e aparece aquela caixa, o nome da caixa é DialogResult
            dialog = MessageBox.Show("Deseja realmente sair? ","Alerta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes) // se o resultado da caixa(DialogResult) for sim, então ele: --->
            {
                Application.Exit();// sai da aplicação
            }
        }

        private void pbxFechar_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult(); 
            dialog = MessageBox.Show("Deseja realmente sair? ", "Alerta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCliente cliente = new FrmCliente();
            cliente.Show();
        }

        private void pbxCliente_Click(object sender, EventArgs e)
        {
            FrmCliente cliente = new FrmCliente();
            cliente.Show();
        }
    }
}
