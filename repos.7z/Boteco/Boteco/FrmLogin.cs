﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading; // essa biblioteca faz que o ''Thread.Sleep(3000); funcione
using System.Windows.Forms;

namespace Boteco
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
            FrmSplash splash = new FrmSplash(); // aqui estancia o form splash, assim criando outro splash e então eu consigo manipular 
            splash.Show(); // faz aparecer o form splash
            Application.DoEvents(); // essa aplicação vai ter alguns eventos, essa linha está aqui por que vai abrir uma trend, trend é tipo as listas do gerenciador de tarefas.
            Thread.Sleep(3000); // abre a trend, e então ela dorme por 3 segundos.
            splash.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close(); // se clicar no cancelar, ira fechar.
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string login, senha;
            login = txtLogin.Text; // a variavel login (tipo string), ira receber o que a pessoa digitar lá no campo txt do txtLogin.
            senha = txtSenha.Text;
            if (login == "admin" && senha == "admin")
            { 
                FrmPrincipal principal = new FrmPrincipal(); // estancia o formPrincipal para poder manipular ele melhor
            principal.Show(); // mostra o formPrincipal na tela (graças a estancia que fizemos logo acima).
            this.Visible = false; // esconde a tela 
        }
        else 
   {
        MessageBox.Show("Suas credenciais não foram validadas!! Tente novamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error); // apresenta a caixinha 
                txtLogin.Text = " "; // limpa os campos
                txtSenha.Text = " "; // limpa os campos
                    this.txtLogin.Focus(); // bota o cursor no campo txtLogin
     }
        }
    }
}
